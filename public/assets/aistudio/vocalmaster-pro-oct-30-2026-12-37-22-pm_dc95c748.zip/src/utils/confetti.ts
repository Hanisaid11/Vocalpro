import confetti from 'canvas-confetti';

/**
 * Celebratory Confetti Explosion for 3-star achievements and level masteries
 */
export function fire3StarCelebration() {
  try {
    // 1. Center burst of colorful stars and geometric shapes
    confetti({
      particleCount: 80,
      spread: 90,
      origin: { y: 0.6 },
      colors: ['#f59e0b', '#fbbf24', '#38bdf8', '#34d399', '#ec4899', '#a855f7'],
      shapes: ['star', 'circle'],
      scalar: 1.2,
      zIndex: 9999,
    });

    // 2. Left and right cannons after short delay
    setTimeout(() => {
      confetti({
        particleCount: 50,
        angle: 60,
        spread: 70,
        origin: { x: 0.1, y: 0.7 },
        colors: ['#fbbf24', '#f59e0b', '#38bdf8'],
        zIndex: 9999,
      });
      confetti({
        particleCount: 50,
        angle: 120,
        spread: 70,
        origin: { x: 0.9, y: 0.7 },
        colors: ['#34d399', '#10b981', '#f43f5e'],
        zIndex: 9999,
      });
    }, 250);
  } catch (e) {
    console.warn('Confetti effect fallback:', e);
  }
}
